import heapq

def best_first_search(starting_state):
    # TODO(III): You should copy your code from MP3 here
    return []

def backtrack(visited_states, goal_state):
    # TODO(III): You should copy your code from MP3 here
    return []